import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { Eye, EyeOff, Phone, Lock } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '../components/ui/Button';
import './Login.css';

export function Login() {
  const navigate = useNavigate();
  const login = useAuthStore((state) => state.login);
  const [activeTab, setActiveTab] = useState('login');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    await new Promise(r => setTimeout(r, 800));
    login('citizen');
    navigate('/citizen');
  };

  return (
    <div className="login-page">
      <motion.div 
        className="login-card glass glass--layer-4"
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: [-6, 0, -6], opacity: 1 }}
        transition={{ 
          y: { duration: 4, repeat: Infinity, ease: "easeInOut" },
          opacity: { duration: 0.6, ease: "easeOut" } 
        }}
      >
        {/* Brand Mark */}
        <motion.div 
          className="login-brand"
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 260, damping: 22 }}
        >
          <div className="login-brand__icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
              <polyline points="9 22 9 12 15 12 15 22"/>
            </svg>
          </div>
          <h1 className="login-brand__title">JanSetu</h1>
          <p className="login-brand__subtitle">Smart Grievance System for Citizens</p>
        </motion.div>

        {/* Tab Toggle */}
        <div className="login-tabs">
          <button
            className={`login-tab ${activeTab === 'login' ? 'active' : ''}`}
            onClick={() => setActiveTab('login')}
          >
            Login
          </button>
          <button
            className={`login-tab ${activeTab === 'signup' ? 'active' : ''}`}
            onClick={() => setActiveTab('signup')}
          >
            Sign Up
          </button>
        </div>

        {/* Login Form */}
        {activeTab === 'login' && (
          <form className="login-form" onSubmit={handleLogin}>
            <div className="login-input-group">
              <label>Mobile Number</label>
              <div className="login-field">
                <span className="login-field__prefix">
                  🇮🇳 +91
                  <span className="login-field__prefix-divider" />
                </span>
                <input
                  type="tel"
                  className="login-input has-prefix"
                  placeholder="98765 43210"
                />
              </div>
            </div>

            <div className="login-input-group">
              <label>Password</label>
              <div className="login-field">
                <input
                  type={showPassword ? 'text' : 'password'}
                  className="login-input"
                  placeholder="Enter your password"
                  style={{ paddingLeft: 14 }}
                />
                <span className="login-input-suffix" onClick={() => setShowPassword(!showPassword)}>
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </span>
              </div>
            </div>

            <Button type="submit" variant="primary" loading={loading} style={{ marginTop: 12, height: 48, fontSize: 16 }}>
              {loading ? 'Signing In…' : 'Continue →'}
            </Button>

            <div className="login-forgot">
              <button type="button">Forgot password?</button>
            </div>
          </form>
        )}

        {/* Sign Up Form */}
        {activeTab === 'signup' && (
          <form className="login-form" onSubmit={handleLogin}>
            <div className="login-input-group">
              <label>Full Name</label>
              <div className="login-field">
                <input type="text" className="login-input" placeholder="Rahul Sharma" style={{ paddingLeft: 14 }} />
              </div>
            </div>

            <div className="login-input-group">
              <label>Mobile Number</label>
              <div className="login-field">
                <span className="login-field__prefix">
                  🇮🇳 +91
                  <span className="login-field__prefix-divider" />
                </span>
                <input type="tel" className="login-input has-prefix" placeholder="98765 43210" />
              </div>
            </div>

            <div className="login-input-group">
              <label>Password</label>
              <div className="login-field">
                <input type={showPassword ? 'text' : 'password'} className="login-input" placeholder="Create a strong password" style={{ paddingLeft: 14 }} />
                <span className="login-input-suffix" onClick={() => setShowPassword(!showPassword)}>
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </span>
              </div>
            </div>

            <div className="login-input-group">
              <label>Confirm Password</label>
              <div className="login-field">
                <input type={showConfirm ? 'text' : 'password'} className="login-input" placeholder="Repeat your password" style={{ paddingLeft: 14 }} />
                <span className="login-input-suffix" onClick={() => setShowConfirm(!showConfirm)}>
                  {showConfirm ? <EyeOff size={18} /> : <Eye size={18} />}
                </span>
              </div>
            </div>

            <div className="login-checkbox">
              <input type="checkbox" id="terms" />
              <label htmlFor="terms">
                I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
              </label>
            </div>

            <Button type="submit" variant="primary" loading={loading} style={{ marginTop: 12, height: 48, fontSize: 16 }}>
              {loading ? 'Creating Account…' : 'Create Account →'}
            </Button>
          </form>
        )}

        {/* Divider */}
        <div className="login-divider">
          <span>or continue with</span>
        </div>

        {/* Social Buttons */}
        <div className="login-social">
          <button type="button" className="login-social-btn">
            <svg width="18" height="18" viewBox="0 0 24 24">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Continue with Google
          </button>
          <button type="button" className="login-social-btn">
            <Phone size={18} style={{ color: 'var(--teal-primary)' }} />
            Login with OTP
          </button>
        </div>

        {/* Switch tab link */}
        <div style={{ textAlign: 'center', marginTop: 24, paddingTop: 16, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
          <button
            type="button"
            onClick={() => setActiveTab(activeTab === 'login' ? 'signup' : 'login')}
            style={{
              fontSize: 13, color: 'var(--teal-primary)', fontWeight: 600,
              background: 'none', border: 'none', cursor: 'pointer',
              transition: 'opacity 0.2s'
            }}
          >
            {activeTab === 'login'
              ? 'New here? Create account →'
              : 'Already have an account? Sign in →'}
          </button>
        </div>

      </motion.div>
    </div>
  );
}
